# Microsoft Developer Studio Project File - Name="ArmDrv" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 5.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Dynamic-Link Library" 0x0102

CFG=ArmDrv - Win16 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "ArmDrv.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "ArmDrv.mak" CFG="ArmDrv - Win16 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ArmDrv - Win16 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "ArmDrv - Win16 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 

# Begin Project
# PROP Scc_ProjName ""$/ArmDrv", FJBAAAAA"
# PROP Scc_LocalPath "."
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MT /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /MT /W3 /GX /O2 /X /I "C:\dxsdk\DDK\Inc16" /I "C:\dxsdk\DDK\Inc" /I "C:\dxsdk\sdk\inc" /I "C:\MSVC\INCLUDE" /D "NDEBUG" /D "_WINDOWS" /D "NOWINDOWSX" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x809 /d "NDEBUG"
# ADD RSC /l 0x809 /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /machine:I386
# ADD LINK32 libw.lib dibeng.lib /nologo /subsystem:windows /dll /machine:I386 /nodefaultlib /out:"Release\ArmDrv.drv"
# Begin Special Build Tool
SOURCE=$(InputPath)
PostBuild_Cmds=rc16 -31 -b armdrv.res armdrv.drv
# End Special Build Tool

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 1
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MTd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /YX /FD /c
# ADD CPP /nologo /ML /W3 /GX /Z7 /Od /X /I "DDK\Inc16" /I "DDK\Inc" /I "sdk\inc" /I "MSVC\INCLUDE" /D "_DEBUG" /D "_WINDOWS" /D "NOWINDOWSX" /FR /FD /G2 /AM /GA /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /o NUL /win32
# ADD BASE RSC /l 0x809 /d "_DEBUG"
# ADD RSC /l 0x809 /fo"Debug\armdrv.res" /i "DDK\Inc16" /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:windows /dll /debug /machine:I386 /pdbtype:sept
# ADD LINK32 libw.lib dibeng.lib DDK\Lib16\ldllcew.lib DDK\Lib16\kernel.lib /subsystem:windows /verbose /dll /incremental:no /map /debug /debugtype:both /machine:I386 /nodefaultlib /out:"Debug/ArmDrv.drv" /NOE /LI /AL:16
# SUBTRACT LINK32 /nologo /profile
# Begin Special Build Tool
SOURCE=$(InputPath)
PostBuild_Desc=Binding Resources to executable.
PostBuild_Cmds=rc16 -31 -b .\armdrv.res debug\armdrv.drv
# End Special Build Tool

!ENDIF 

# Begin Target

# Name "ArmDrv - Win16 Release"
# Name "ArmDrv - Win16 Debug"
# Begin Group "Resources"

# PROP Default_Filter "*.bin"
# Begin Source File

SOURCE=.\Res\Colortab.bin
# End Source File
# Begin Source File

SOURCE=.\Res\Config.bin
# End Source File
# Begin Source File

SOURCE=.\Res\Display.rc

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Res\Fonts.bin
# End Source File
# Begin Source File

SOURCE=.\Res\Fonts120.bin
# End Source File
# Begin Source File

SOURCE=.\Res\Version.h
# End Source File
# End Group
# Begin Group "Include Files"

# PROP Default_Filter ".inc"
# Begin Source File

SOURCE=.\Cmacros.inc
# End Source File
# Begin Source File

SOURCE=.\Dibeng.inc
# End Source File
# Begin Source File

SOURCE=.\Gdidefs.inc
# End Source File
# Begin Source File

SOURCE=.\Macros.inc
# End Source File
# Begin Source File

SOURCE=.\Minivdd.inc
# End Source File
# Begin Source File

SOURCE=.\Valmode.inc
# End Source File
# End Group
# Begin Source File

SOURCE=.\armdrv.def
# End Source File
# Begin Source File

SOURCE=.\armdrv.res
# End Source File
# Begin Source File

SOURCE=.\Diblink.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Diblink.asm
InputName=Diblink

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Diblink.asm
InputName=Diblink

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Disable.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Disable.asm
InputName=Disable

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Disable.asm
InputName=Disable

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Enable.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build
OutDir=.\Release
InputPath=.\Enable.asm
InputName=Enable

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Enable.asm
InputName=Enable

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Getresid.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Getresid.asm
InputName=Getresid

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Getresid.asm
InputName=Getresid

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Init.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Init.asm
InputName=Init

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Init.asm
InputName=Init

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Palette.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Palette.asm
InputName=Palette

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Palette.asm
InputName=Palette

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Sswitch.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Sswitch.asm
InputName=Sswitch

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Sswitch.asm
InputName=Sswitch

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\Vga.asm

!IF  "$(CFG)" == "ArmDrv - Win16 Release"

# Begin Custom Build - Assembling .asm file
OutDir=.\Release
InputPath=.\Vga.asm
InputName=Vga

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ELSEIF  "$(CFG)" == "ArmDrv - Win16 Debug"

# Begin Custom Build
OutDir=.\Debug
InputPath=.\Vga.asm
InputName=Vga

"$(OutDir)\$(InputName).obj" : $(SOURCE) "$(INTDIR)" "$(OUTDIR)"
	ml -nologo -c -Zm -Zi -Cp -Fo$(OutDir)\$(InputName).obj $(InputName).asm

# End Custom Build

!ENDIF 

# End Source File
# End Target
# End Project
